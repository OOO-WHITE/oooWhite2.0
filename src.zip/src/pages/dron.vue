<template>
  <q-page class="row">
    <div class="col">
      <q-table
        class="col"
        style="height: 400px"
        title="F-1"
        :data="data"
        :columns="columns"
        virtual-scroll
        :pagination.sync="pagination"
        :rows-per-page-options="[0]"
      />
    <br/>
    <q-btn color="green-5" label="Connect to server" class="full-width" v-on:click="add_data"/>
    <br/>
    <h5 class="text-center text-weight-bolder" style="color: red">{{ErrorMessage}}</h5>
    </div>
  </q-page>
</template>
<script>
export default {
  name: 'PageIndex',
  data () {
    return {
      Mishanya_lol: 0,
      ErrorMessage: '',
      // dd
      data: [
        {
          Time: new Date(),
          parA: 0,
          parB: 0,
          parC: 0
        }
      ],
      colums: [
        { name: 'Time', label: 'Time', field: '' },
        { name: 'ParA', label: 'ParA', field: '' },
        { name: 'ParB', label: 'ParB', field: '' },
        { name: 'ParC', label: 'ParC', field: '' }
      ]
    }
  },
  methods: {
    async add_data () {
      const time = new Date()
      const ss = String(time.getSeconds())
      const mm = String(time.getMinutes())
      const hh = String(time.getHours())
      const dd = String(time.getDay())
      // send the request
      var adress = 'http://172.20.10.5:3000/get_dron_info$'
      const response = await fetch(adress)
      var mes = await response.text()
      mes = mes.split('&')
      const newData = {
        Time: ss + ':' + mm + ':' + hh + ' Day: ' + dd,
        parA: mes[0],
        parB: mes[1],
        parC: mes[2]
      }
      if ((parseInt(mes[0]) >= 90) || (parseInt(mes[1]) >= 90) || (parseInt(mes[2]) >= 90)) {
        this.ErrorMessage = 'Code 1, check parms ' + String(mes[0]) + ' ' + String(mes[1]) + ' ' + String(mes[2])
      } else {
        this.ErrorMessage = ''
      }
      this.data.push(newData)
      setTimeout(this.add_data, 10000)
    }
  }
}
</script>
