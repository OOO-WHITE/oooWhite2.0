<template>
   <q-page class="row">
     <div class="q-pa-md col" style="max-width:500px">
       <h3>Login</h3>
            <q-input color="blue-11" outlined v-model="login_input" label="Login"></q-input>
        <br/>
            <q-input color="blue-11" outlined v-model="password_input" label="Password"></q-input>
        <br/>
            <q-btn outline class="full-width" color="blue-14" label="Login" size="18px" v-on:click="Chek_user" />
     </div>
     <div class="q-pa-md col" v-show="access">
       <h3>Create new user</h3>
            <q-input color="blue-11" outlined v-model="name_input" label="Name"></q-input>
        <br/>
            <q-input color="blue-11" outlined v-model="login_input" label="Login"></q-input>
        <br/>
            <q-input color="blue-11" outlined v-model="password_input" label="Password"></q-input>
        <br/>
            <q-select color="blue-11" outlined v-model="role_input" :options="roles" label="Role" />
        <br/>
            <q-btn outline class="full-width" color="blue-14" label="Create" size="18px" v-on:click="Create_user" />
     </div>
   </q-page>
</template>
<script>
export default {
  name: 'PageIndex',
  data () {
    return {
      name_input: '',
      login_input: '',
      password_input: '',
      role_input: '',
      roles: [
        'admin', 'moderator'
      ],
      access: false
    }
  },
  methods: {
    async Create_user () {
      // name, login, password, role
      var adress = 'http://172.20.10.5:3000/create_user$'
      if (this.name_input !== '' && this.login_input !== '' && this.password_input !== '' && this.role_input !== '') {
        var url = adress + this.name_input + '&' + this.login_input + '&' + this.password_input + '&' + this.role_input
        alert(url)
        const request = await fetch(url)
        console.log(request)
      } else {
        alert('Feel all colums')
      }
    },
    async Chek_user () {
      var adress = 'http://172.20.10.5:3000/get_user_info$'
      var url = adress + this.login_input
      const response = await fetch(url)
      alert(` Sending the request\n ${url}`)
      var mes = await response.text()
      // name, login, password, role
      mes = mes.split('&')
      if (this.login_input === mes[1] && this.password_input === mes[2]) {
        this.access = true
      } else {
        alert('Incorrect password')
      }
      this.login_input = ''
      this.password_input = ''
    }
  }
}
</script>
