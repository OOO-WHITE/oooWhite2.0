<template>
  <q-page class="flex flex-center">
    <div class="q-pa-md q-gutter-sm">
    <q-btn style="background: #7FBF3F; color: white" label="click to get money" size="15px" v-on:click="click_plus" />
    <q-btn style="background: #EC7063; color: white" label="click to spend money" size="15px" v-on:click="click_minus" />
    <body>
    <h6 class="flex flex-center">{{Mishanya_lol}}$</h6>
    <span style="color:#EC7063" class="flex flex-center text-no-wrap" aria-setsize="20px">{{ErrorMessage}}</span>
    </body>
    <div class="column items-center" style="height: 150px">
    <q-btn round color="indigo-5" icon="assignment_ind" v-on:click="GoToLogin"/>
    </div>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  data () {
    return {
      Mishanya_lol: 0,
      ErrorMessage: '',
      PromoCode_input: '',
      PromoCode: 'Crocodil_gena_1991'
    }
  },

  methods: {
    click_minus () {
      if ((this.Mishanya_lol - 5) < 0) {
        this.ErrorMessage = 'You dont hzve enough money'
      } else {
        this.Mishanya_lol -= 5
        this.ErrorMessage = ''
      }
    },
    click_plus () {
      this.Mishanya_lol += 1
    },
    prom_check () {
      if (this.PromoCode_input === this.PromoCode) {
        this.ErrorMessage = 'Promocode is succesfull, you have earned 100$'
        this.Mishanya_lol += 100
        this.PromoCode_input = ''
      } else {
        this.ErrorMessage = 'Promocode is incorrect, sorry'
        this.PromoCode_input = ''
      }
    },
    GoToLogin () {
      this.$router.push('login')
    }
  }
}
</script>
