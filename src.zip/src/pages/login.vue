<script src="https://www.gstatic.com/firebasejs/8.0.2/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.2/firebase-firestore.js"></script>
<template>
   <q-page class="row justify-center">
    <div class="q-pa-md col-5">
    <h3>Enter admin data</h3>
    <q-form
      @submit="onSubmit"
      @reset="onReset"
      class="q-gutter-md"
      >
      <q-input
        filled
        v-model="Login_input"
        label="Login *"
        hint="Name and surname"
        lazy-rules
      />

      <q-input
        filled
        type="Password"
        v-model="Password_Input"
        label="Password *"
        lazy-rules
      />
      <div>
        <q-btn label="Submit" type="submit" color="primary" v-on:click="Save_order_data"/>
        <q-btn label="Reset" type="reset" color="primary" flat class="q-ml-sm" />
      </div>
    </q-form>
    <br/>
    <p v-show="Acces">Super mega secrete information, hi admin.</p>
  </div>
   </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  data () {
    return {
      Password: 'Mishanya top',
      Login: 'adm',
      Password_Input: '',
      Login_input: '',
      Acces: false
    }
  },

  methods: {
    check_data () {
      if (this.Password_Input === this.Password && this.Login_input === this.Login) {
        this.Acces = true
        alert('Dear admin, thank you for your returning')
      } else {
        alert('Incorecct password, try again later')
      }
      this.Login_input = ''
      this.Password_Input = ''
    },
    Save_order_data () {
      firebase.initializeApp({
        apiKey: 'AIzaSyBwfsEn6qx36UzkLTNKSmW_mKYc4HRXmN8',
        authDomain: 'localhost',
        projectId: 'dron-5e28f'
      })
      var db = firebase.firestore()
      // Save data to cloud
      db.collection("order_data").add({
        Client_dron: "AA",
        Client_order: "#1",
      }).then(function(docRef) {
        console.log("Document written with ID: ", docRef.id);
      }).catch(function(error) {
        console.error("Error adding document: ", error);
      });
    }
  }
}
</script>
