<template>
  <q-page class="row">
    <div class="q-pa-md col">
       <div class="q-pa-md col">
       <h3>Login</h3>
            <q-input color="blue-11" outlined v-model="login_input" label="Login"></q-input>
        <br/>
            <q-input color="blue-11" outlined v-model="password_input" label="Password"></q-input>
        <br/>
            <q-btn outline class="full-width" color="blue-14" label="Login" size="18px" v-on:click="Chek_user" />
     </div>
    </div>
    <div class="q-pa-md col" v-show="access">
        <h3>Create new order</h3>
            <q-input color="orange-4" outlined v-model="Client_mail" label="client mail"></q-input>
        <br/>
            <q-input color="orange-4" outlined v-model="Client_tel" label="client tel"></q-input>
        <br/>
            <q-select color="orange-4" outlined v-model="Client_dron" :options="Drons" label="client dron" />
        <br/>
            <q-input color="orange-4" outlined v-model="Client_order" label="client order"></q-input>
        <br/>
            <q-btn outline class="full-width" color="orange-6" label="Create" size="18px" v-on:click="send_data" />
    </div>
    <div class="q-pa-md col" v-show="access">
        <h3>Order information</h3>
        <q-input color="green-4" outlined v-model="ID_info" label="Order ID"></q-input>
        <br/>
        <q-btn outline color="green-4" label="Check order info" size="18px" v-on:click="check_data" />
        <br/>
        <a class="text-subtitle1 text-weight-bolder">Order information:</a>
        <br/>
        <a class="text-body1">E-mail: {{Mail_info}}</a>
        <br/>
        <a class="text-body1">Tel: {{Tel_info}}</a>
        <br/>
        <a class="text-body1">Dron: {{Dron_info}}</a>
        <br/>
        <a class="text-body1">Oder id: {{Order_info}}</a>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  data () {
    return {
      Client_mail: '',
      Client_tel: '',
      Client_dron: '',
      Client_order: '',
      Drons: [
        'F-1', 'S-2'
      ],
      ID_info: '',
      Mail_info: '',
      Tel_info: '',
      Dron_info: '',
      Order_info: '',
      login_input: '',
      password_input: '',
      access: false
    }
  },
  methods: {
    async send_data () {
      var adress = 'http://172.20.10.5:3000/create_order$'
      if (this.Client_mail !== '' && this.Client_tel !== '' && this.Client_dron !== '' && this.Client_order !== '') {
        var result = ` Email: ${this.Client_mail}\n Tel: ${this.Client_tel}\n Dron: ${this.Client_dron}\n Order: ${this.Client_order}`
        // mail, tel, dron, order
        var url = adress + this.Client_mail + '&' + this.Client_tel + '&' + this.Client_dron + '&' + this.Client_order
        alert(result)
        const request = await fetch(url)
        alert(request)
        alert(url)
      } else {
        alert('feel all colums')
      }
    },
    async check_data () {
      var adress = 'http://172.20.10.5:3000/get_order_info$'
      var url = adress + this.ID_info
      const response = await fetch(url)
      alert(` Sending the request\n ${url}`)
      var mes = await response.text()
      mes = mes.split('&')
      this.Mail_info = mes[0]
      this.Tel_info = mes[1]
      this.Dron_info = mes[2]
      this.Order_info = mes[3]
    },
    async Chek_user () {
      var adress = 'http://172.20.10.5:3000/get_user_info$'
      var url = adress + this.login_input
      const response = await fetch(url)
      var mes = await response.text()
      // name, login, password, role
      mes = mes.split('&')
      if (this.login_input === mes[1] && this.password_input === mes[2]) {
        this.access = true
      } else {
        alert('Incorrect password')
      }
      this.login_input = ''
      this.password_input = ''
    }
  }
}
</script>
