<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar color="orange-4">
        <q-btn unelevated style="background: white; color: #254E70" label="Basic Menu">
        <q-menu fit anchor="bottom left" self="top left">
          <q-item clickable>
            <q-item-section v-on:click="go_to_order">Order</q-item-section>
          </q-item>
              <q-item clickable>
            <q-item-section v-on:click="go_to_reg">User managment</q-item-section>
            </q-item>
          <q-item clickable>
            <q-item-section v-on:click="go_to_dron">Drons information</q-item-section>
          </q-item>
        </q-menu>
        </q-btn>
        <q-toolbar-title>
          OOO "WHITE"
        </q-toolbar-title>

        <div>Quasar v{{ $q.version }}</div>
      </q-toolbar>
    </q-header>
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>

export default {
  name: 'MainLayout',
  data () {
    return {
      leftDrawerOpen: false
    }
  },
  methods: {
    go_to_order () {
      this.$router.push('order')
    },
    go_to_reg () {
      this.$router.push('reg')
    },
    go_to_dron () {
      this.$router.push('dron')
    }
  }
}
</script>
